from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///movie.db'
app.config['SECRET_KEY'] = '0f7a56dddd7f013a0329f9ac'
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)


from movie import routes