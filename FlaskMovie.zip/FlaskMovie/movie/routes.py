from movie import app
from flask import render_template, redirect, url_for, flash
from movie.models import User
from movie.forms import RegisterForm
from movie import db

@app.route('/')
@app.route('/home')
def home_page():

    items_1 = [
    {'rank': 1, 'name': 'Avatar', 'year_of_release': 2009, 'director': 'James Cameron'},
    {'rank': 2, 'name': 'Avengers: Endgame', 'year_of_release': 2019, 'director': 'Joe Russo, Anthony Russo'},
    {'rank': 3, 'name': 'Titanic', 'year_of_release': 1997, 'director': 'James Cameron'},
    {'rank': 4, 'name': 'Star Wars: The Force Awakens', 'year_of_release': 2015, 'director': 'J.J Abrams'},
    {'rank': 5, 'name': 'Avengers: Infinity War', 'year_of_release': 2018, 'director': 'Joe Russo, Anthony Russo'}
    ]

    items_2 = [
    {'rank': 1, 'name': 'Hamilton', 'director': 'Thomas Kail', 'imdb_rating': 8.5},
    {'rank': 2, 'name': 'The Father', 'director': 'Florian Zeller', 'imdb_rating': 8.3},
    {'rank': 3, 'name': 'Soul', 'director': 'Pete Docter, Kemp Powers', 'imdb_rating': 8.1},
    {'rank': 4, 'name': ' Another Round ', 'director': 'Thomas Vinterberg', 'imdb_rating': 7.8},
    {'rank': 5, 'name': 'Crip Cramp', 'director': 'James Lebrecht', 'imdb_rating': 7.7}
    ]

    return render_template('home.html', items_1 = items_1, items_2 = items_2)

@app.route('/about us')
def about_us_page():
    return render_template('about_us.html')

@app.route('/register', methods=['GET', 'POST'])
def register_page():
    form = RegisterForm()
    if form.validate_on_submit():
        user_to_create = User(username=form.username.data,
                                email_address=form.email_address.data,
                                password=form.password1.data)
        db.session.add(user_to_create)
        db.session.commit()
        return redirect(url_for('home_page'))

    if form.errors != {}: #if there are no errors from the validation
        for err_msg in form.errors.values():
            flash(f'There was an error with creating an user: {err_msg}', category='danger')

    return render_template('register.html', form=form) 